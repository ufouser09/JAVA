package nerdle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.io.Serializable;

public class Denklem implements Serializable{
	private static final long serialVersionUID = 1L;
	private ArrayList<Integer> numbers;
	private String equation;
	private int length;
	
	public Denklem() {
		numbers = new ArrayList<>();
	}
	
	public void twoAdd() {
		numbers.add(numbers.get(0)+numbers.get(1)+numbers.get(2));
		equation = numbers.get(0)+"+"+numbers.get(1)+"+"+numbers.get(2)+"="+numbers.get(3);
	}
	
	public void oneAddOneSub(int firstProcess) {
		numbers.add(numbers.get(0)+numbers.get(1)-numbers.get(2));
		if(firstProcess == 0) {
			equation = numbers.get(0)+"+"+numbers.get(1)+"-"+numbers.get(2)+"="+numbers.get(3);
		}
		else {
			equation = numbers.get(3)+"-"+numbers.get(1)+"+"+numbers.get(2)+"="+numbers.get(0);
		}
	}
	
	public String twoSub() {
		twoAdd();
		return numbers.get(3)+"-"+numbers.get(1)+"-"+numbers.get(2)+"=" + numbers.get(0);
	}
	
	public void oneAddOneMux(int firstProcess) {
		numbers.add(numbers.get(0)+numbers.get(1)*numbers.get(2));
		if(firstProcess == 0)
			equation = numbers.get(0)+"+"+numbers.get(1)+"*"+numbers.get(2)+"="+numbers.get(3);
		else
			equation = numbers.get(2)+"*"+numbers.get(1)+"+"+numbers.get(0)+"="+numbers.get(3);
	}
	
	public void oneAddOneDiv(int firstProcess, int bound) {
		Random rand = new Random();
		numbers.remove(2);
		numbers.remove(1);
		int tmp = rand.nextInt(bound-numbers.get(0));
		if(tmp == 0)
			numbers.add(rand.nextInt(bound-1)+1);
		else
			numbers.add(rand.nextInt((bound-1)/tmp)+1);
		numbers.add(numbers.get(1)*tmp);
		numbers.add(numbers.get(0)+tmp);
		if(firstProcess == 0)
			equation = numbers.get(0)+"+"+numbers.get(2)+"/"+numbers.get(1)+"="+numbers.get(3);
		 else
			equation = numbers.get(2)+"/"+numbers.get(1)+"+"+numbers.get(0)+"="+numbers.get(3);
	}
	
	public void oneSubOneMux(int firstProcess) {
		if(firstProcess == 1) {
			numbers.add(numbers.get(0)-numbers.get(1)*numbers.get(2));
			equation = numbers.get(0)+"-"+numbers.get(1)+"*"+numbers.get(2)+"="+numbers.get(3);
		}
		else {
			numbers.add(numbers.get(0)*numbers.get(1)-numbers.get(2));
			equation = numbers.get(0)+"*"+numbers.get(1)+"-"+numbers.get(2)+"="+numbers.get(3);
		}
	}
	
	public void oneSubOneDiv(int firstProcess, int bound) {
		oneAddOneDiv(0,bound);
		Random rand = new Random();
		if(firstProcess == 1)
			equation = numbers.get(3)+"-"+numbers.get(2)+"/"+numbers.get(1)+"="+numbers.get(0);
		else {
			numbers.add(rand.nextInt(numbers.get(2)/numbers.get(1)+1));
			equation = numbers.get(2)+"/"+numbers.get(1)+"-"+numbers.get(4)+"="+(numbers.get(2)/numbers.get(1)-numbers.get(4));
		}
	}
	
	public void twoMux() {
		numbers.add(numbers.get(0)*numbers.get(1)*numbers.get(2));
		equation = numbers.get(0)+"*"+numbers.get(1)+"*"+numbers.get(2)+"="+numbers.get(3);
	}
	
	public void oneMuxOneDiv(int firstProcess) {
		Random rand = new Random();
		numbers.remove(2);
		numbers.add(rand.nextInt(9)+1);
		if(firstProcess == 2) {
			if((numbers.get(0)*numbers.get(1) % numbers.get(2)) == 0) {
				numbers.add(numbers.get(0)*numbers.get(1)/numbers.get(2));
				equation = numbers.get(0)+"*"+numbers.get(1)+"/"+numbers.get(2)+"="+numbers.get(3);
			}
			else {
				equation = " ";
			}
		}
		else {
			if(numbers.get(0)%numbers.get(2) == 0) {
				numbers.add(numbers.get(0)/numbers.get(2)*numbers.get(1));
				equation = numbers.get(0)+"/"+numbers.get(2)+"*"+numbers.get(1)+"="+numbers.get(3);
			}
			else {
				equation = " ";
			}
		}
	}
	
	public void twoDiv() {
		twoMux();
		while(numbers.get(1)==0 || numbers.get(2) == 0) {
			twoMux();
		}
		equation = numbers.get(3) + "/" + numbers.get(1) + "/" + numbers.get(2) +"="+numbers.get(0);
	}
	
	public void separate(int length,int bound) {
		Random rand = new Random();
		do {
			numbers.clear();
			numbers.add(rand.nextInt(bound));
			numbers.add(rand.nextInt(bound));
			numbers.add(rand.nextInt(bound));
			if(rand.nextBoolean()) {
				/*
				 * 	Tek i�lemli
				 */
				if(rand.nextBoolean()) {
					/*
					 * Sa�da
					 */
					numbers.add(numbers.get(1)*10 + numbers.get(2));
					numbers.remove(2);			numbers.remove(1);
					int tmp = rand.nextInt(2);
					if(tmp == 0) {
						numbers.add(numbers.get(0)+numbers.get(1));
						equation = numbers.get(0)+"+"+numbers.get(1)+"="+numbers.get(2);
					}
					else {
						numbers.add(numbers.get(0)*numbers.get(1));
						equation = numbers.get(0)+"*"+numbers.get(1)+"="+numbers.get(2);
					}
				}
				else{
					/*
					 * Solda
					 */
					numbers.add(numbers.get(0)*10 + numbers.get(1));
					numbers.remove(1);			numbers.remove(0);
			        Collections.swap(numbers, 0, 1);
			        int tmp = rand.nextInt(4);
			        if(tmp == 0) {
						numbers.add(numbers.get(0)+numbers.get(1));
						equation = numbers.get(0)+"+"+numbers.get(1)+"="+numbers.get(2);
					}
			        else if(tmp == 1) {
						numbers.add(numbers.get(0)-numbers.get(1));
						equation = numbers.get(0)+"-"+numbers.get(1)+"="+numbers.get(2);
			        }
					else if(tmp == 2){
						numbers.add(numbers.get(0)*numbers.get(1));
						equation = numbers.get(0)+"*"+numbers.get(1)+"="+numbers.get(2);
					}
					else {
						numbers.add(numbers.get(0)*numbers.get(1));
						if(numbers.get(0)!=0) {
							equation = numbers.get(2)+"/"+numbers.get(0)+"="+numbers.get(1);
						}
						else{
							equation = "0/" + (rand.nextInt(900)+100) + "=0";
						}
					}
				}
			}
			else {
				/*
				 *  �ift i�lemli
				 */
				int tmp = rand.nextInt(4);
				if(tmp == 0) {
					tmp = rand.nextInt(4);
					if(tmp == 0) {
						twoAdd();
					}
			        else if(tmp == 1) {
			        	oneAddOneSub(0);
			        }
					else if(tmp == 2){
						oneAddOneMux(0);
					}
					else {
						oneAddOneDiv(0,bound);
					}
				}
		        else if(tmp == 1) {
		        	tmp = rand.nextInt(4);
					if(tmp == 0) {
						oneAddOneSub(1);
					}
			        else if(tmp == 1) {
			        	twoSub();
			        }
					else if(tmp == 2){
						oneSubOneMux(1);
					}
					else {
						oneSubOneDiv(1,bound);
					}
		        }
				else if(tmp == 2){
					tmp = rand.nextInt(4);
					if(tmp == 0) {
						oneAddOneMux(2);
					}
			        else if(tmp == 1) {
			        	oneSubOneMux(2);
			        }
					else if(tmp == 2){
						twoMux();
					}
					else {
						oneMuxOneDiv(2);
					}
				}
				else {
					tmp = rand.nextInt(4);
					if(tmp == 0) {
						oneAddOneDiv(3,bound);
					}
			        else if(tmp == 1) {
			        	oneSubOneDiv(3,bound);
			        }
					else if(tmp == 2){
						oneMuxOneDiv(3);
					}
					else {
						twoDiv();
					}
				}
			}
		}while(equation.length()!=length);
	}
	
	public void generateEquation() {
		Random rand = new Random();
		length = 7 + rand.nextInt(3);
		if(length == 7) {
			separate(7,10);
		}
		else if(length == 8) {
			separate(8,100);
		}
		else {
			separate(9,100);
		}
	}

	public String getEquation() {
		return equation;
	}

	public int getLength() {
		return length;
	}
	
	public boolean calculate(ArrayList<String> entered) {
		ArrayList<String> operators = new ArrayList<>();
        ArrayList<Integer> operands = new ArrayList<>();
        int i = 0, kat=10, tmp = 0, result;
        while(entered.get(i).compareTo("=") != 0) {
        	tmp = 0;
        	while(entered.get(i).compareTo("0") >= 0 && entered.get(i).compareTo("9") <= 0) {
        		tmp = tmp * kat + Integer.parseInt(entered.get(i));
        		i++;
        	}
        	operands.add(tmp);
        	if(entered.get(i).compareTo("=") != 0) {
        		operators.add(entered.get(i));
        		i++;
        	}
        }
        if(operators.size() == 1) {
        	if(operators.get(0).compareTo("+") == 0)
        		result = operands.get(0) + operands.get(1);
        	else if(operators.get(0).compareTo("-") == 0)
        		result = operands.get(0) - operands.get(1);
        	else if(operators.get(0).compareTo("*") == 0)
        		result = operands.get(0) * operands.get(1);
        	else if(operands.get(1) != 0)
        		result = operands.get(0) / operands.get(1);
        	else
        		return false;
        }
        else {
        	if(operators.get(0).compareTo("+") == 0) {
        		if(operators.get(1).compareTo("+") == 0) {
            		result = operands.get(0) + operands.get(1) + operands.get(2);
            	}
            	else if(operators.get(1).compareTo("-") == 0) {
            		result = operands.get(0) + operands.get(1) - operands.get(2);
            	}
            	else if(operators.get(1).compareTo("*") == 0) {
            		result = operands.get(0) + operands.get(1) * operands.get(2);
            	}
            	else if(operands.get(2) != 0) {
            		result = operands.get(0) + operands.get(1) / operands.get(2);
            	}
            	else
            		return false;
        	}
        	else if(operators.get(0).compareTo("-") == 0) {
        		if(operators.get(1).compareTo("+") == 0) {
        			result = operands.get(0) - operands.get(1) + operands.get(2);
            	}
            	else if(operators.get(1).compareTo("-") == 0) {
            		result = operands.get(0) - operands.get(1) - operands.get(2);
            	}
            	else if(operators.get(1).compareTo("*") == 0) {
            		result = operands.get(0) - operands.get(1) * operands.get(2);
            	}
            	else if(operands.get(2) != 0) {
            		result = operands.get(0) - operands.get(1) / operands.get(2);
            	}
            	else
            		return false;
        	}
        	else if(operators.get(0).compareTo("*") == 0) {
        		if(operators.get(1).compareTo("+") == 0) {
        			result = operands.get(0) * operands.get(1) + operands.get(2);
            	}
            	else if(operators.get(1).compareTo("-") == 0) {
            		result = operands.get(0) * operands.get(1) - operands.get(2);
            	}
            	else if(operators.get(1).compareTo("*") == 0) {
            		result = operands.get(0) * operands.get(1) * operands.get(2);
            	}
            	else if(operands.get(2) != 0) {
            		result = operands.get(0) * operands.get(1) / operands.get(2);
            	}
            	else
            		return false;
        	}
        	else if(operands.get(1) != 0) {
        		if(operators.get(1).compareTo("+") == 0) {
        			result = operands.get(0) / operands.get(1) + operands.get(2);
            	}
            	else if(operators.get(1).compareTo("-") == 0) {
            		result = operands.get(0) / operands.get(1) - operands.get(2);
            	}
            	else if(operators.get(1).compareTo("*") == 0) {
            		result = operands.get(0) / operands.get(1) * operands.get(2);
            	}
            	else if(operands.get(2) != 0) {
            		result = operands.get(0) / operands.get(1) / operands.get(2);
            	}
            	else
            		return false;
        	}
        	else
        		return false;
        }
        
        i++;
        if(entered.get(i).compareTo("-") == 0) {
        	i++;
        	tmp = 0;
        	while(i < entered.size()) {
        		tmp = tmp * kat + Integer.parseInt(entered.get(i));
        		i++;
        	}
        	tmp*=-1;
        	if(result == tmp)
        		return true;
        	return false;
        }
    	tmp = 0;
    	while(i < entered.size()) {
    		tmp = tmp * kat + Integer.parseInt(entered.get(i));
    		i++;
    	}
    	if(result == tmp)
    		return true;
    	return false;
	}
	
}
