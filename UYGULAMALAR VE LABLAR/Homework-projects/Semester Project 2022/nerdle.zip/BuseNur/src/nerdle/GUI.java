package nerdle;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class GUI extends JFrame{
	private static final long serialVersionUID = 1L;
	public static final int DEFAULT_WIDTH = 700;
	public static final int DEFAULT_HEIGHT = 700;  
	
	//		PANELS:
	private JPanel entrancePanel, testPanel, gamePanel, buttonPanel;
	private JPanel panel1, panel2, panel3, panel4, panel5, panel6;
	//		BUTTONS:
	private JButton zero, one, two, three, four, five, six, seven, eight, nine;
	private JButton add, sub, mux, div, equal;
	private JButton guess, del, later, main;
	private JButton newGame, continueGame, test, test2;
	//		TextFields:
	private JTextField selected;
	private ArrayList<JTextField> t1, t2, t3, t4, t5, t6;
	private ArrayList<ArrayList<JTextField>> allT;
	
	private Denklem equation;
	private Statistic statistic;
	private ArrayList<String> entered;
	private int trueGuess;
	private int level;
	private long begin, end;
	
	public static void main(String[] args) {
	      EventQueue.invokeLater(new Runnable() {
	          public void run() {
	        	 GUI frame = new GUI();
	             frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	             frame.setVisible(true);
	          }
	       });
	}
	
	public GUI() {
		initComponent();
	}
	
	protected void initComponent() {
		t1 = new ArrayList<>();
		t2 = new ArrayList<>();
		t3 = new ArrayList<>();
		t4 = new ArrayList<>();
		t5 = new ArrayList<>();
		t6 = new ArrayList<>();
		allT = new ArrayList<>();
		entered = new ArrayList<String>();
		
		setTitle("Buse Nur Pekmezci");
		setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); 
		setLocation(screenSize.width/5,screenSize.height/10);
		
		/*
		 * 		Entrance:
		 * */
		try {
			FileInputStream fileIn = new FileInputStream("statistic.ser");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			statistic = (Statistic) in.readObject();
			in.close();
			fileIn.close();
		} catch (IOException | ClassNotFoundException e) {
			statistic = new Statistic();
		}
		
		entrancePanel = new JPanel(new GridLayout(9,1));
		add(entrancePanel);
		entrancePanel.setVisible(true);
		
		JLabel left = new JLabel("B�rak�lan oyun say�s�: "+statistic.getNumberOfLeft(),JLabel.CENTER);
		JLabel fail = new JLabel("Kaybedilen oyun say�s�: "+statistic.getFail(),JLabel.CENTER);
		JLabel success = new JLabel("Kazan�lan oyun say�s�: "+statistic.getSuccess(),JLabel.CENTER);
		JLabel average = new JLabel("Ortalama ka��nc� sat�r: "+statistic.getAverage(),JLabel.CENTER);
		JLabel time = new JLabel("Ortalama zaman: "+statistic.getTime()+" saniye",JLabel.CENTER);
		JLabel createdBy = new JLabel("Created by 20011001 - Buse Nur Pekmezci",JLabel.CENTER);
		
		newGame = new JButton("Yeni Oyun");
		continueGame = new JButton("Devam Et");
		test = new JButton("Test Et");
		test2 = new JButton("Test Et");
		
		entrancePanel.add(left);
		entrancePanel.add(fail);
		entrancePanel.add(success);
		entrancePanel.add(average);
		entrancePanel.add(time);
		entrancePanel.add(newGame);
		entrancePanel.add(continueGame);
		entrancePanel.add(test);
		entrancePanel.add(createdBy);
		
		JLabel equ = new JLabel();
		test.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				equation = new Denklem();
				entrancePanel.setVisible(false);
				testPanel = new JPanel(new GridLayout(3,1));
				add(testPanel);
				testPanel.setVisible(true);
				testPanel.add(equ);
				equation.generateEquation();
				equ.setText(equation.getEquation()+" Uzunluk: "+equation.getLength());
				testPanel.add(test2);
				testPanel.add(createdBy);
			}
		});
		
		test2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				equation.generateEquation();
				equ.setText(equation.getEquation()+" Uzunluk: "+equation.getLength());
			}
		});
		
		buttonPanel = new JPanel();
		ButtonAction action = new ButtonAction();
		zero = new JButton("0");
		zero.addActionListener(action);
		one = new JButton("1");
		one.addActionListener(action);
		two = new JButton("2");
		two.addActionListener(action);
		three = new JButton("3");
		three.addActionListener(action);
		four = new JButton("4");
		four.addActionListener(action);
		five = new JButton("5");
		five.addActionListener(action);
		six = new JButton("6");
		six.addActionListener(action);
		seven = new JButton("7");
		seven.addActionListener(action);
		eight = new JButton("8");
		eight.addActionListener(action);
		nine = new JButton("9");
		nine.addActionListener(action);
		add = new JButton("+");
		add.addActionListener(action);
		sub = new JButton("-");
		sub.addActionListener(action);
		mux = new JButton("*");
		mux.addActionListener(action);
		div = new JButton("/");
		div.addActionListener(action);
		equal = new JButton("=");
		equal.addActionListener(action);
		guess = new JButton("Tahmin Et");
		guess.addActionListener(action);
		del = new JButton("Sil");
		del.addActionListener(action);
		later = new JButton("Sonra Bitir");
		later.addActionListener(action);
		main = new JButton("Ana Sayfaya D�n");
		main.addActionListener(action);
		
		buttonPanel.add(zero);
		buttonPanel.add(one);
		buttonPanel.add(two);
		buttonPanel.add(three);
		buttonPanel.add(four);
		buttonPanel.add(five);
		buttonPanel.add(six);
		buttonPanel.add(seven);
		buttonPanel.add(eight);
		buttonPanel.add(nine);
		buttonPanel.add(add);
		buttonPanel.add(sub);
		buttonPanel.add(mux);
		buttonPanel.add(div);
		buttonPanel.add(equal);
		buttonPanel.add(guess);
		buttonPanel.add(del);
		buttonPanel.add(later);
		
		panel1 = new JPanel();
		panel2 = new JPanel();
		panel3 = new JPanel();
		panel4 = new JPanel();
		panel5 = new JPanel();
		panel6 = new JPanel();
		
		TextAction ta = new TextAction();
		for(int i=0; i<7; i++) {
			JTextField text = new JTextField(5);
			text.addMouseListener(ta);
			panel1.add(text);
			t1.add(text);
		}
		for(int i=0; i<7; i++) {
			JTextField text = new JTextField(5);
			text.addMouseListener(ta);
			panel2.add(text);
			t2.add(text);
		}
		for(int i=0; i<7; i++) {
			JTextField text = new JTextField(5);
			text.addMouseListener(ta);
			panel3.add(text);
			t3.add(text);
		}
		for(int i=0; i<7; i++) {
			JTextField text = new JTextField(5);
			text.addMouseListener(ta);
			panel4.add(text);
			t4.add(text);
		}
		for(int i=0; i<7; i++) {
			JTextField text = new JTextField(5);
			text.addMouseListener(ta);
			panel5.add(text);
			t5.add(text);
		}
		for(int i=0; i<7; i++) {
			JTextField text = new JTextField(5);
			text.addMouseListener(ta);
			panel6.add(text);
			t6.add(text);
		}
		allT.add(t1);
		allT.add(t2);
		allT.add(t3);
		allT.add(t4);
		allT.add(t5);
		allT.add(t6);
		gamePanel = new JPanel(new GridLayout(8,1));
		gamePanel.add(buttonPanel);
		gamePanel.add(panel1);
		gamePanel.add(panel2);
		gamePanel.add(panel3);
		gamePanel.add(panel4);
		gamePanel.add(panel5);
		gamePanel.add(panel6);
		gamePanel.add(createdBy);
		
		newGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				statistic.level.clear();
				equation = new Denklem();
				statistic.setLastTime(0);
				equation.generateEquation();
				entrancePanel.setVisible(false);
				add(gamePanel);
				begin = System.currentTimeMillis();
				if(equation.getLength() == 7)
					sevenGameComponent(1);
				else if(equation.getLength() == 8)
					eightGameComponent(1);
				else
					nineGameComponent(1);
			}
		});
		
		final int a = statistic.getLeft();
		continueGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(a != 0) {
					equation = statistic.equation;
					entrancePanel.setVisible(false);
					add(gamePanel);
					if(equation.getLength() == 7)
						sevenGameComponent(0);
					else if(equation.getLength() == 8)
						eightGameComponent(0);
					else
						nineGameComponent(0);
				}
				else {
					JOptionPane.showMessageDialog(null, "KAYIT YOK");
				}
			}
		});
		
	}

	protected void nineGameComponent(int isNew) {
		JTextField text;
		TextAction ta = new TextAction();
		for(int i=0;i<2;i++) {
			text = new JTextField(5);
			text.addMouseListener(ta);
			t1.add(text);
			panel1.add(text);
		}
		for(int i=0;i<2;i++) {
			text = new JTextField(5);
			text.addMouseListener(ta);
			t2.add(text);
			panel2.add(text);
		}
		for(int i=0;i<2;i++) {
			text = new JTextField(5);
			text.addMouseListener(ta);
			t3.add(text);
			panel3.add(text);
		}
		for(int i=0;i<2;i++) {
			text = new JTextField(5);
			text.addMouseListener(ta);
			t4.add(text);
			panel4.add(text);
		}
		for(int i=0;i<2;i++) {
			text = new JTextField(5);
			text.addMouseListener(ta);
			t5.add(text);
			panel5.add(text);
		}
		for(int i=0;i<2;i++) {
			text = new JTextField(5);
			text.addMouseListener(ta);
			t6.add(text);
			panel6.add(text);
		}
		
		if(isNew == 1) {
			setEnab(t2,false);
			setEnab(t3,false);
			setEnab(t4,false);
			setEnab(t5,false);
			setEnab(t6,false);
			level = 0;
		}
		else {
			int i = 0;
			for(ArrayList<String> last: statistic.level) {
				entered = new ArrayList<>();
				for(int j=0;j<9;j++) {
					allT.get(i).get(j).setText(last.get(j));
					entered.add(last.get(j));
				}
				equation.calculate(entered);
				color();
			}
			for(ArrayList<JTextField> t:allT) {
				setEnab(t,false);
			}
			setEnab(allT.get(statistic.lastLevel),true);
		}
		
	}

	protected void eightGameComponent(int isNew) {
		JTextField text = new JTextField(5);
		TextAction ta = new TextAction();
		text.addMouseListener(ta);
		t1.add(text);
		panel1.add(text);
		text = new JTextField(5);
		text.addMouseListener(ta);
		t2.add(text);
		panel2.add(text);
		text = new JTextField(5);
		text.addMouseListener(ta);
		t3.add(text);
		panel3.add(text);
		text = new JTextField(5);
		text.addMouseListener(ta);
		t4.add(text);
		panel4.add(text);
		text = new JTextField(5);
		text.addMouseListener(ta);
		t5.add(text);
		panel5.add(text);
		text = new JTextField(5);
		text.addMouseListener(ta);
		t6.add(text);
		panel6.add(text);
		
		if(isNew == 1) {
			setEnab(t2,false);
			setEnab(t3,false);
			setEnab(t4,false);
			setEnab(t5,false);
			setEnab(t6,false);
			level = 0;
		}
		else {
			int i = 0;
			for(ArrayList<String> last: statistic.level) {
				entered = new ArrayList<>();
				for(int j=0;j<8;j++) {
					allT.get(i).get(j).setText(last.get(j));
					entered.add(last.get(j));
				}
				equation.calculate(entered);
				color();
			}
			for(ArrayList<JTextField> t:allT) {
				setEnab(t,false);
			}
			setEnab(allT.get(statistic.lastLevel),true);
		}
		
	}

	protected void sevenGameComponent(int isNew) {
		
		if(isNew == 1) {
			setEnab(t2,false);
			setEnab(t3,false);
			setEnab(t4,false);
			setEnab(t5,false);
			setEnab(t6,false);
			level = 0;
		}
		else {
			int i = 0;
			for(ArrayList<String> last: statistic.level) {
				entered = new ArrayList<>();
				for(int j=0;j<7;j++) {
					allT.get(i).get(j).setText(last.get(j));
					entered.add(last.get(j));
				}
				equation.calculate(entered);
				color();
				i++;
			}
			for(ArrayList<JTextField> t:allT) {
				setEnab(t,false);
			}
			setEnab(allT.get(statistic.lastLevel),true);
		}
		
	}
	
	protected void setEnab(ArrayList<JTextField> t, boolean bool) {
		for(JTextField tf : t) {
			tf.setEnabled(bool);
		}
	}
	
	private class TextAction implements MouseListener{
		@Override
		public void mouseClicked(MouseEvent event) {
			selected = (JTextField) event.getSource();
		}

		@Override
		public void mousePressed(MouseEvent e) {}
		@Override
		public void mouseReleased(MouseEvent e) {}
		@Override
		public void mouseEntered(MouseEvent e) {}
		@Override
		public void mouseExited(MouseEvent e) {}
	}
	
	private class ButtonAction implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			if(event.getSource() == guess) {
				entered = new ArrayList<>();
				for(int i=0; i<equation.getLength(); i++) {
					if(allT.get(level).get(i).getText().isEmpty() || allT.get(level).get(i).getText().compareTo(" ") == 0) {
						JOptionPane.showMessageDialog(null, "BO� ALAN");
						return;
					}
					else {
						entered.add(allT.get(level).get(i).getText());
					}
				}
				if(equation.calculate(entered)) {
					color();
					if(trueGuess == equation.getLength()) {
						end = System.currentTimeMillis();
						int time = ((int) (end - begin)) / 1000;
						time += statistic.lastTime;
						statistic.win(level,time);
						JOptionPane.showMessageDialog(null, "KAZANDINIZ\nGE�EN S�RE = "+time+" saniye");
						setEnab(allT.get(level),false);
						try {
							FileOutputStream fileOut = new FileOutputStream("statistic.ser");
							ObjectOutputStream out = new ObjectOutputStream(fileOut);
							out.writeObject(statistic);
							out.close();
							fileOut.close();
						} catch (IOException i) {
							i.printStackTrace();
						}
					}
					else if(level == 6) {
						statistic.lose(level);
						JOptionPane.showMessageDialog(null, "KAYBETT�N�Z\nDENKLEM = "+equation.getEquation());
						buttonPanel.removeAll();
						buttonPanel.add(main);
						try {
							FileOutputStream fileOut = new FileOutputStream("statistic.ser");
							ObjectOutputStream out = new ObjectOutputStream(fileOut);
							out.writeObject(statistic);
							out.close();
							fileOut.close();
						} catch (IOException i) {
							i.printStackTrace();
						}
					}
					else {
						statistic.addLevel(entered);
					}
					
				}
				else {
					JOptionPane.showMessageDialog(null, "��LEM TUTARSIZ");
				}
			} else if(event.getSource() == later) {
				end = System.currentTimeMillis();
				int time = ((int) (end - begin)) / 1000;
				statistic.leave(equation, level, time);
				setEnab(allT.get(level),false);
				try {
					FileOutputStream fileOut = new FileOutputStream("statistic.ser");
					ObjectOutputStream out = new ObjectOutputStream(fileOut);
					out.writeObject(statistic);
					out.close();
					fileOut.close();
				} catch (IOException i) {
					i.printStackTrace();
				}
			} else if (event.getSource() == main) {
				gamePanel.setVisible(false);
				initComponent();
			} else if(selected == null) {
				return;
			} else if (event.getSource() == zero) {
				selected.setText("0");
			} else if (event.getSource() == one) {
				selected.setText("1");
			} else if (event.getSource() == two) {
				selected.setText("2");
			} else if (event.getSource() == three) {
				selected.setText("3");
			} else if (event.getSource() == four) {
				selected.setText("4");
			} else if (event.getSource() == five) {
				selected.setText("5");
			} else if (event.getSource() == six) {
				selected.setText("6");
			} else if (event.getSource() == seven) {
				selected.setText("7");
			} else if (event.getSource() == eight) {
				selected.setText("8");
			} else if (event.getSource() == nine) {
				selected.setText("9");
			} else if (event.getSource() == add) {
				selected.setText("+");
			} else if (event.getSource() == sub) {
				selected.setText("-");
			} else if (event.getSource() == mux) {
				selected.setText("*");
			} else if (event.getSource() == div) {
				selected.setText("/");
			} else if (event.getSource() == equal) {
				selected.setText("=");
			} else if (event.getSource() == del) {
				selected.setText(" ");
				int i;
				for(ArrayList<JTextField> t: allT) {
					for(i=0;i<t.size() && t.get(i) != selected; i++);
					if(i != t.size() && i!=0) {
						selected = t.get(i-1);
						return;
					}
				}
			}
		}
	}

	public void color() {
		int i = 0;
		trueGuess = 0;
		while(i < equation.getLength()) {
			if(entered.get(i).compareTo(equation.getEquation().substring(i, i+1)) == 0) {
				allT.get(level).get(i).setBackground(Color.GREEN);
				trueGuess++;
			}
			else if(equation.getEquation().contains(entered.get(i)) == true) {
				allT.get(level).get(i).setBackground(Color.YELLOW);
			}
			else {
				allT.get(level).get(i).setBackground(Color.RED);
			}
			i++;
		}
		setEnab(allT.get(level),false);
		level++;
		if(level < 6) {
			setEnab(allT.get(level),true);
		}
	}
}
