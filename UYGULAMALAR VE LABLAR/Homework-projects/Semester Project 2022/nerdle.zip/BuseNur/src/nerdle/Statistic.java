package nerdle;

import java.io.Serializable;
import java.util.ArrayList;

public class Statistic implements Serializable{
	private static final long serialVersionUID = 1L;
	public Denklem equation;
	public int lastLevel;
	public ArrayList<ArrayList<String>> level;

	public int numberOfLeft;
	public int left;
	public int fail;
	public int success;
	public int average;
	public int time;
	public int lastTime;
	
	public Statistic() {
		numberOfLeft = left = fail = success = average = lastLevel = time = 0;
		equation = new Denklem();
		level = new ArrayList<ArrayList<String>>();
	}
	
	public int getNumberOfLeft() {
		return numberOfLeft;
	}
	public int getLeft() {
		return left;
	}
	public int getFail() {
		return fail;
	}
	public int getSuccess() {
		return success;
	}
	public int getAverage() {
		return average;
	}
	public int getTime() {
		return time;
	}

	public void setAverage(int level) {
		int tmp = average*success;
		tmp += level;
		success++;
		tmp = tmp / success;
		this.average = tmp;
	}

	public void setTime(int time) {
		int tmp = this.time*(success-1);
		tmp = tmp + time;
		tmp = tmp / success;
		this.time = tmp;
	}

	public void win(int level, int time) {
		setAverage(level);
		setTime(time);
		left = 0;
		this.level.clear();
	}

	public void lose(int level) {
		fail++;
		left = 0;
		this.level.clear();
	}
	
	public void leave(Denklem equation, int level, int lastTime) {
		setEquation(equation);
		setLastLevel(level);
		left = 1;
		numberOfLeft++;
		this.lastTime = lastTime;
	}
	
	public void setEquation(Denklem equation) {
		this.equation = equation;
	}

	public void setLastLevel(int lastLevel) {
		this.lastLevel = lastLevel;
	}

	public void setLastTime(int lastTime) {
		this.lastTime = lastTime;
	}

	public void addLevel(ArrayList<String> entered) {
		level.add(entered);
	}
	
}
