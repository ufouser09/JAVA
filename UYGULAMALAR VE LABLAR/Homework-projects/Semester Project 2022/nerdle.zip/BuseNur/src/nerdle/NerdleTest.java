package nerdle;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.*;

public class NerdleTest {
	private Denklem equation;

	@Before
	public void setUp() {
		equation = new Denklem();
	}
	
	@Test
	public void testLenEqualLength( ) {
		setUp();
		equation.generateEquation();
		assertTrue(equation.getEquation().length() == equation.getLength());
	}

	@Test
	public void testLenBetween7and9() {
		equation.generateEquation();
		assertTrue(equation.getLength() < 10 && equation.getLength() > 6);
	}

	@Test
	public void testEquationTrue() {
		equation.generateEquation();
		String[] tmp = equation.getEquation().split("");
		ArrayList<String> equ = new ArrayList<>();
		for(int i=0; i<tmp.length ;i++) {
			equ.add(tmp[i]);
		}
    	assertTrue(equation.calculate(equ));
	}

	@Test
	public void testEquationReallyRandom() throws Exception {
		Denklem equ2 = new Denklem();
		equation.generateEquation();
		equ2.generateEquation();
		assertFalse(equation.getEquation().compareTo(equ2.getEquation()) == 0);
	}
}
