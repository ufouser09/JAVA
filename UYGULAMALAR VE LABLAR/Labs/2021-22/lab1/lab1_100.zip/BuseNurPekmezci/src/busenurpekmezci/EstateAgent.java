package busenurpekmezci;

public class EstateAgent {
	private String name;
	private Home[] h = new Home[10];
	
	public void setName(String name) {
		this.name = name;
	}

	public void listHome() {
		System.out.println("Welcome to "+getName());
		System.out.println("Here is the homes:");
		int i=0;
		while(h[i]!=null) {
			System.out.println(h[i]);
			i++;
		}
	}
	
	public void hasHome(Home h1) {
		int i=0;
		while(h[i] != null)
			i++;
		h[i] = h1;
	}
	
	public void sellHome(Home home, Customer customer) {
		int i=0;
		while(h[i] != null && h[i] != home)
			i++;
		if(h[i] == null) {
			System.out.println("Ev bulunmamakta.");
			return;
		}
		else {
			customer.buyHome(home);
			while(h[i]!=null) {
				h[i] = h[i+1];
				i++;
			}
		}
		
	}
	
	public String getName() {
		return name;
	}
	
}
