package busenurpekmezci;

public class Customer {
	private String name;
	private String telephone;
	private String address;
	private Home[] hm = new Home[10];
	private int homeCounter;
	private double payment;
	
	public Customer(String name, String telephone, String address) {
		this.name = name;
		this.telephone = telephone;
		this.address = address;
		homeCounter = 0;
		payment = 0;
	}
	
	public void buyHome(Home home) {
		if(homeCounter < 2) {
			hm[homeCounter] = home;
			homeCounter++;
			payment+=home.getPrice();
		}
		else {
			hm[homeCounter] = home;
			homeCounter++;
			payment+=home.discountedPrice();
		}
	}
	
	public void listHome() {
		int i=0;
		while(hm[i]!=null && i<2) {
			System.out.println(hm[i]);
			i++;
		}
		System.out.println(hm[i].toStringWithDiscounted());
	}
	
	public String getInfo() {
		String info;
		int tmp = getHomeCounter();
		info = name+" has "+tmp+" home(s) with total payment: "+getPayment();
		return info;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getHomeCounter() {
		return homeCounter;
	}

	public void setHomeCounter(int homeCounter) {
		this.homeCounter = homeCounter;
	}

	public double getPayment() {
		return payment;
	}

	public void setPayment(double payment) {
		this.payment = payment;
	}

	public void listLocations() {
		int i=0, count, j, k;
		String counted[] = new String[10];
		while(hm[i]!=null) {
			counted[i] = hm[i].getLocation();
			k=0;
			while(k<i && counted[k] != counted[i]) {
				k++;
			}
			// Say�lan evin tekrar say�lmamas� i�in b�yle bir sistem geli�tirdim
			if(k==i) {
				count = 1;
				j = i+1;
				while(hm[j] != null) {
					if(hm[j].getLocation() == counted[i]) {
						count++;
					}
					j++;
				}
				System.out.println("At city "+hm[i].getLocation()+"---> "+count+" home(s)");
			}
			i++;
		}
	}
	
}
