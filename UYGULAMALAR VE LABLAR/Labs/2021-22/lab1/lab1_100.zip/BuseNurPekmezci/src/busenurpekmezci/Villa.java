package busenurpekmezci;

public class Villa extends Home {
	
	public Villa(double price, String location) {
		super(price,location);
	}

	@Override
	public double discountedPrice() {
		double temp;
		temp = this.getPrice();
		temp = temp - temp * 0.1;
		return temp;
	}

	@Override
	public String toString() {
		String intro;
		intro = "Home Category: Villa, Price: "+ getPrice() +", Location: "+getLocation();
		return intro;
	}

	@Override
	public String toStringWithDiscounted() {
		String intro;
		intro = "Home Category: Villa, Price: "+ discountedPrice() +", Location: "+getLocation();
		return intro;
	}
	
}
