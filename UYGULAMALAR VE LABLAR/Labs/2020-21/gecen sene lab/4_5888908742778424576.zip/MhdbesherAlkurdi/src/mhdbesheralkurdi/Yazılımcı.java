package mhdbesheralkurdi;

public class Yazılımcı extends Calisan {
	private int certificate;
	
	public Yazılımcı(String isim, int years, int certificate, int salary) {
		super(isim, years, salary);
		this.certificate = certificate;
	}

	@Override
	public void zamYap() {
		super.setSalary(getSalary()*1.15);
		super.setYears(getYears() + 1);
	}

	public int getCertificate() {
		return certificate;
	}

	public void setCertificate(int certificate) {
		this.certificate = certificate;
	}
	
	public String kendiniTanıt() {
		return "İsmim: "+this.getIsim()+", "+this.getYears()+" yıldır çalışıyorum. "+this.getSalary()+" lira maaş alıyorum. " +this.getCertificate()+ " adet sertifikam var.";
	}
}
