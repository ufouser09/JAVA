package mhdbesheralkurdi;

public class Analist extends Calisan {
	public Analist(String isim, int years, int salary) {
		super(isim, years, salary);
	}
	@Override
	public void zamYap() {
		super.setSalary(getSalary()*1.1);
		super.setYears(getYears() + 1);
	}
	
	public String kendiniTanıt() {
		return "İsmim: "+this.getIsim()+", "+this.getYears()+" yıldır çalışıyorum. "+this.getSalary()+" lira maaş alıyorum.";
	}
}
