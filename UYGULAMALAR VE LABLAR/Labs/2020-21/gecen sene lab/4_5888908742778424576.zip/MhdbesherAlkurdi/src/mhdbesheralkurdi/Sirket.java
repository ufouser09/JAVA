package mhdbesheralkurdi;

public class Sirket {
	private String name;
	private Departman[] departmanlar;

	public Sirket(String name) {
		this.name = name;
		this.departmanlar = new Departman[4];
		for (int i = 0; i < departmanlar.length; i++) {
			departmanlar[i] = new Departman();
		}
	}

	public String getName() {
		return name;
	}

	public void sirketTanıt() {
		int i = 0;
		for (Departman departman : departmanlar) {
			int analysts = 0, programmers = 0;
			for (Calisan calisankisi : departman.getCalisanlar()) {
				if (calisankisi == null) {
					continue;
				}
				if (calisankisi instanceof Analist) {
					analysts++;
				} else {
					programmers++;
				}
			}
			System.out.println(i + " numaralı departmanda "+analysts+" tane Analist, "+programmers+" tane Yazılımcı vardır.");
			i++;
		}
		
	}

	public void calisanEkle(Calisan calisan) {
		for (Departman departman : departmanlar) {
			if (departman.addCalisan(calisan)) {
				return;
			}
		}
		System.out.println("Sirket dolu calisan eklenemedi");
		return;
	}

	public void depMaasOrt(int i) {
		int maasSum = 0, maasNum = 0;
		for (Calisan calisan : departmanlar[i].getCalisanlar()) {
			if (calisan != null) {
				maasSum += calisan.getSalary();
				maasNum++;
			}
		}
		if (maasNum == 0) {
			System.out.println(i + "numaralı departmanda çalışanların maaş ortalaması: 0");
		} else {
			System.out.println(i + "numaralı departmanda çalışanların maaş ortalaması: " + maasSum / maasNum);
		}
	}

	public void maxGorevYili() {
		int maxYears = 0, numToPrint = 0;
		Calisan[] kidemli = new Calisan[10];
		for (Departman departman : departmanlar) {
			for (Calisan calisan : departman.getCalisanlar()) {
				if(calisan==null) {
					continue;
				}
				if (calisan.getYears() > maxYears) {
					maxYears = calisan.getYears();
					kidemli[0] = calisan;
					numToPrint = 1;
				} else if (calisan.getYears() == maxYears) {
					kidemli[numToPrint] = calisan;
					numToPrint++;
				}
			}
		}
		for (int i = 0; i < numToPrint; i++) {
			System.out.println(kidemli[i].getIsim());
		}
	}
	
}
