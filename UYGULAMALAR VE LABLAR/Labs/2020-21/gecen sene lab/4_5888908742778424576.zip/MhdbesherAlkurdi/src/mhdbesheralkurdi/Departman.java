package mhdbesheralkurdi;

public class Departman {
	private Calisan[] calisanlar;

	public Departman() {
		this.calisanlar = new Calisan[3];
	}
	
	public boolean addCalisan(Calisan aCalisan) {
		for (int i = 0; i < calisanlar.length; i++) {
			if (calisanlar[i] == null) {
				calisanlar[i] = aCalisan;
				return true;
			}
		}
		return false;
	}

	public Calisan[] getCalisanlar() {
		return calisanlar;
	}
	
	
}
