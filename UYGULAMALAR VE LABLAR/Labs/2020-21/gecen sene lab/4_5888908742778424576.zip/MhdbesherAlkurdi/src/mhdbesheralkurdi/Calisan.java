package mhdbesheralkurdi;

public abstract class Calisan {
	protected String isim;
	protected int years;
	protected double salary;
	public abstract void zamYap();
	public abstract String kendiniTanıt();
	public Calisan(String isim, int years, int salary) {
		this.isim = isim;
		this.years = years;
		this.salary = salary;
	}
	public int getYears() {
		return years;
	}
	public void setYears(int years) {
		this.years = years;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getIsim() {
		return isim;
	}
	
}
