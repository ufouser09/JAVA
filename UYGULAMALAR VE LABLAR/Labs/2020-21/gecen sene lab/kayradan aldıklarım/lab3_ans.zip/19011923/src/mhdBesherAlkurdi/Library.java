package mhdBesherAlkurdi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;

public class Library {
	private HashMap<Student, Book> libMap = new HashMap<Student, Book>();
	private ArrayList<Student> studentQueue = new ArrayList<Student>();
	private LinkedList<Book> books = new LinkedList<Book>();

	public void borrowBook(ArrayList<Student> stu_list, LinkedList<Book> book_list) {
		this.books = book_list;
		Iterator<Book> it2 = book_list.iterator();
		while ((!stu_list.isEmpty()) && it2.hasNext()) {
			Student student = stu_list.get(0);
			Book book = it2.next();
			libMap.put(student, book);
			stu_list.remove(0);
		}
		studentQueue = stu_list;
	}
	
	

	public void mapPrint() {
		if (libMap.isEmpty()) {
			System.out.println("No students to borrow book");
			return;
		}
		for (Map.Entry<Student, Book> entry : libMap.entrySet()) {
			Student student = entry.getKey();
			Book book = entry.getValue();
			System.out.println(student.getNumber() + " numbered student borrowed -> " + book.getName());
		}
	}



	public void returnBook(Student s2) {
		if (libMap.containsKey(s2)) {
			Book book = libMap.remove(s2);
			if (studentQueue.isEmpty()) {
				return;
			}
			Student student = studentQueue.remove(0);
			libMap.put(student, book);
			
		} else {
			System.out.println(s2.getName() + " has already returned the book.");
		}
	}
	
	public boolean hasBook(String nameSearch, String authorSearch) {
		for (Book book : books) {
			if (book.getName().contentEquals(nameSearch) && book.getAuthor().contentEquals(authorSearch)) {
				return true;
			}
		}
		return false;
	}
	
	public void newBook() throws BookException {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter book name:");
		String bookSearch = scanner.nextLine();
		System.out.println("Enter author name:");
		String authorSearch = scanner.nextLine();
		scanner.close();
		if (this.hasBook(bookSearch, authorSearch)) {
			throw new BookException("Library has this book!");
		}
		books.add(new Book(bookSearch, authorSearch));
	}
	
}
