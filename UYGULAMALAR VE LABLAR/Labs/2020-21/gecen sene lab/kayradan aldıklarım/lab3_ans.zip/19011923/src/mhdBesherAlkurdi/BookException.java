package mhdBesherAlkurdi;

public class BookException extends Exception {
	public BookException(String s) {
		super(s);
	}
}
