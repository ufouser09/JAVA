package mhdBesherAlkurdi;

import java.util.List;

public class MyInfoClass {
	public static < C > void getObjectInfo(C obj) {
		System.out.println(obj.toString());
	}

	public static < L > void getListInfo(List<L> stu_list) {
		for (L l : stu_list) {
			System.out.println(l.toString());
		}
	}
	
	
}
